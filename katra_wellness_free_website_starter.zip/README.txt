KATRA WELLNESS — FREE WEBSITE STARTER

Included:
- index.html: mobile-friendly, no-image website draft
- Booking form: prepares a WhatsApp message after you add your business number
- Service prices are intentionally not listed yet; confirm rates with service providers first.

IMPORTANT BEFORE PUBLISHING
1. Open index.html in a browser to preview.
2. In index.html, find: const WHATSAPP_NUMBER = "91XXXXXXXXXX";
3. Replace it with your dedicated business WhatsApp number in international format, digits only (India example: 91 followed by the 10-digit number). Keep your personal number separate.
4. Review the service names, duration, operating arrangements, and local legal/business requirements before accepting bookings.
5. Do not advertise any service, price, provider credential, or availability that has not been verified.

FREE HOSTING OPTIONS
This is a coded website draft, not yet a live website. For a no-cost public URL, GitHub Pages can host this static page for free, but requires a GitHub account and uploading index.html to a repository. If you prefer Google Sites, use this page as a visual/content reference and recreate the sections in Google Sites; Google Sites does not directly import an HTML page as a full website.

The booking form currently opens WhatsApp; it does not store bookings in a database or automatically confirm appointments.
